/*  AddressSpace.c - Discover the address space layout by printing
    relevant addresses in the stack, data and bss segments */

#include <stdio.h>
#include <stdlib.h>
#include <alloca.h>
#include <unistd.h>

int const a = 0xaaaa;
int b = 0xbbbb;
int c;

int main(int argc, char * argv[]) {
    c = 0xcccc;
	int d = 0xdddd;
    printf("%p:main\n", &main);
    printf("%p:a=%0x\n", (void *) &a, a);
    printf("%p:b=%0x\n", (void *) &b, b);
    printf("%p:c=%0x\n", (void *) &c, c);
    printf("%p:d=%0x\n", (void *) &d, d);
    printf("%p:argc=%0x\n", (void *) &argc, argc);

 	int *e_ptr = (int*) malloc(sizeof(int));
  	printf("%p:e=%0x\n", (void *) e_ptr, *e_ptr);
	int *f_ptr = (int*) alloca(sizeof(int));
  	printf("%p:f=%0x\n", (void *) f_ptr, *f_ptr);
    return 0;
}

/*  Please note that the checks on the return value of the system calls
    have been omitted to avoid cluttering the code. However, system calls
    can and will fail, in which case the results are unpredictable. */