/bin/rm -rf ln.dir
mkdir ln.dir
cd ln.dir

echo "Hello World" >a
ln a b
ls -li
rm a
cat b
ln b a
ls -li
ln -s a c
cat c
/bin/rm a b
ls -li
cat c
echo "Hello World" >a
ls -li
cat c
cd ..
