/*  StackLayout.c - Discover the stack layout by printing the stack of three
    nested calls. The stack grows from high to low addresses. Within a
    stack frame the argument declared last is stored at the lowest address
    and the local variable declared first sits at the highest address. */

#include <stdio.h>

#define N 4
int *q;

void bar(int e, int f) {
    int g = 0x1010, h = 0x0101;
    int *p;
    printf("s/%p/&:e/\ns/%p/&:f/\ns/%p/&:g/\ns/%p/&:h/\ns/%p/&:p/\n",
        (void *) &e, (void *) &f, (void *) &g, (void *) &h, (void *) &p);
    for(p=&f-N;p<=q;p++){
        printf("#%p\t%0x\n", (void *) p, *p);
    }
}

void foo(int c, int d) {
    printf("s/%p/&:c/\ns/%p/&:d/\n", (void *) &c, (void *) &d);
    bar(0xeeee,0xffff);
}

int main(int argc, char * argv[], char *envp[]) {
    int a = 0xaaaa, b = 0xbbbb;
    printf("s/%p/&:argc/\ns/%p/&:argv/\ns/%p/&:envp/\ns/%p/&:a/\ns/%p/&:b/\n",
        (void *) &argc, (void *) &argv, (void *) &envp, (void *) &a, (void *) &b);
    q = &a+N;
    foo(0xcccc,0xdddd);
    printf("#%p:bar\n#%p:foo\n#%p:main\n#%p:q\n", &bar, &foo, main, (void *) &q);
    return 0;
}
